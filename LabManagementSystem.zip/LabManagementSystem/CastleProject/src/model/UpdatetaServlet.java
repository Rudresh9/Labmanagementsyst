package model;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.*;
import model.*;

/**
 * Servlet implementation class UpdatequestionServlet
 */
@WebServlet("/UpdatetaServlet")
public class UpdatetaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdatetaServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	int q_ta_id=Integer.parseInt(request.getParameter("q_ta_id").trim());
	int mod_id=Integer.parseInt(request.getParameter("mod_id").trim());
	int hint_id=Integer.parseInt(request.getParameter("hint_id").trim());
	String question=request.getParameter("question");
	String valid_answer=request.getParameter("valid_answer");

	
	String hint1=request.getParameter("hint1");
	String hint2=request.getParameter("hint2");
	String hint3=request.getParameter("hint3");

	Createquestionta u=new Createquestionta(q_ta_id,question,valid_answer,3,hint_id,mod_id);
	Createhint y =new Createhint(hint_id,hint1,hint2,hint3);
	u.setQ_txt_id(q_ta_id);
	QuestiontaDao dao;
	y.setHint_id(hint_id);
	HintDao dd;
	
	 response.setContentType("text/html");
     PrintWriter out=response.getWriter();

	try {
		dao = new QuestiontaDao();
		dd = new HintDao(); 
		dao.update(u);
		dd.update(y);
		out.println("<B><a href=editqta.jsp>Question changed...GO BACK</a>");
	} 
	catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}

}
