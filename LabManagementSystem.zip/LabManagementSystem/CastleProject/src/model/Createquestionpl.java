package model;

public class Createquestionpl {
	
	private int expno;
	private int quesno;
	private String question;
	private String ans;
	
	public Createquestionpl(int expno, int quesno,String question, String ans) {
		super();
				
		this.expno = expno;
		this.quesno = quesno;
		this.question = question;
		this.ans = ans;
	
	}



	public int getExpno() {
		return expno;
	}



	public void setExpno(int expno) {
		this.expno = expno;
	}



	public int getQuesno() {
		return quesno;
	}



	public void setQuesno(int quesno) {
		this.quesno = quesno;
	}



	public String getQuestion() {
		return question;
	}



	public void setQuestion(String question) {
		this.question = question;
	}



	public String getAns() {
		return ans;
	}



	public void setAns(String ans) {
		this.ans = ans;
	}



	public Createquestionpl() {
		super();
	}



	
	
}
