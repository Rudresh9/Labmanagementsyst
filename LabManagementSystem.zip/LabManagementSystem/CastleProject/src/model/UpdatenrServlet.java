package model;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.*;
import model.*;

/**
 * Servlet implementation class UpdatequestionServlet
 */
@WebServlet("/UpdatenrServlet")
public class UpdatenrServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdatenrServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	int q_num_id=Integer.parseInt(request.getParameter("q_num_id").trim());
	int mod_id=Integer.parseInt(request.getParameter("mod_id").trim());
	int hint_id=Integer.parseInt(request.getParameter("hint_id").trim());
	String question=request.getParameter("question");
	int valid_answer=Integer.parseInt(request.getParameter("valid_answer"));
	double uplimit=Double.parseDouble(request.getParameter("uplimit"));
	double lowlimit=Double.parseDouble(request.getParameter("lowlimit"));
	
	String hint1=request.getParameter("hint1");
	String hint2=request.getParameter("hint2");
	String hint3=request.getParameter("hint3");

	Createquestionnr u=new Createquestionnr(q_num_id,question,valid_answer,2,hint_id,mod_id,uplimit,lowlimit);
	Createhint y =new Createhint(hint_id,hint1,hint2,hint3);
	u.setQ_num_id(q_num_id);
	QuestionnrDao dao;
	y.setHint_id(hint_id);
	HintDao dd;
	
	 response.setContentType("text/html");
     PrintWriter out=response.getWriter();

	try {
		dao = new QuestionnrDao();
		dd = new HintDao(); 
		dao.update(u);
		dd.update(y);
		out.println("<B><a href=editqnr.jsp>Question changed...GO BACK</a>");
	} 
	catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}

}
