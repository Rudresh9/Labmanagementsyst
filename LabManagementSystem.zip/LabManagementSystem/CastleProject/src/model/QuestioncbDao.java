package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import controller.User;
import model.Assignment;

public class QuestioncbDao {
	String Driver="com.mysql.jdbc.Driver";
	  String url="jdbc:mysql://localhost:3306/castleexpt";
	  String user="root";
	  String password="root";
private Connection con;
private PreparedStatement getanswerPstmt,addquestionPstmt,viewquestionPstmt,updatequestionPstmt,getquestionPstmt,getresultPstmt,editquestionPstmt,getquestiondetailsPstmt;
private String addquestionSql="INSERT INTO quescheckbox(q_cb_id,question,answer_1,answer_2,answer_3,answer_4,type_ques_no,hint_id,answer,mod_id)VALUES(?,?,?,?,?,?,?,?,?,?)";
private String viewquestionSql="SELECT * FROM quescheckbox";
private String getquestionSql="SELECT mod_id,Q_cb_id,question,answer_1,answer_2,answer_3,answer_4,answer FROM quescheckbox WHERE mod_id=?";
private String getresultSql="SELECT * FROM quescheckbox WHERE question=?";
private String getquestiondetailsSql="SELECT * FROM quescheckbox WHERE q_cb_id=?";
private String getanswerSql="SELECT mod_id,q_cb_id,question,answer_1,answer_2,answer_3,answer_4,answer FROM quescheckbox WHERE q_cb_id=?";
private String editquestionSql="UPDATE quescheckbox SET question=?,answer_1=?,answer_2=?,answer_3=?,answer_4=?,answer=? WHERE q_cb_id=?";
//private String validateSql="SELECT FIRSTNAME,LASTNAME,EMAILID,GENDER,ADDRESS,CITY,STATE,PIN,INSTITUTENAME,DEGREE,YEAROFPASSING,USERNAME,PASSWORD,USERID FROM USERTABLE WHERE USERNAME=? AND PASSWORD=?";
public QuestioncbDao()throws ClassNotFoundException,SQLException
{
	  Class.forName(Driver);
	  con=DriverManager.getConnection(url, user, password);
	  addquestionPstmt=con.prepareStatement(addquestionSql);
	  viewquestionPstmt=con.prepareStatement(viewquestionSql);
	  getquestionPstmt=con.prepareStatement(getquestionSql);
	  getresultPstmt=con.prepareStatement(getresultSql);
	  getanswerPstmt=con.prepareStatement(getanswerSql);
	  editquestionPstmt=con.prepareStatement(editquestionSql);
	  //validatePstmt=con.prepareStatement(validateSql);
      getquestiondetailsPstmt=con.prepareStatement(getquestiondetailsSql);	  
}
public void create(Createquestioncb u)throws SQLException
{
	  addquestionPstmt.setInt(1,u.getQ_cb_id());
	  addquestionPstmt.setString(2, u.getQuestion());
	  addquestionPstmt.setString(3, u.getAnswer_1());
	  addquestionPstmt.setString(4, u.getAnswer_2());
	  addquestionPstmt.setString(5, u.getAnswer_3());
	  addquestionPstmt.setString(6, u.getAnswer_4());
	  addquestionPstmt.setInt(7,u.getType_ques_no());
	  addquestionPstmt.setInt(8,u.getHint_id());
	  addquestionPstmt.setString(9, u.getAnswer());
	  addquestionPstmt.setInt(10,u.getMod_id());
	  
	  addquestionPstmt.executeUpdate();
	  
}
public ArrayList view()throws SQLException
{
  ResultSet rs=viewquestionPstmt.executeQuery();
  ArrayList<Createquestioncb> al=new ArrayList<Createquestioncb>();
  while(rs.next())
  {
	  int q_cb_id=rs.getInt(1);
	  String question=rs.getString(2);
	  String answer_1=rs.getString(3);
	  String answer_2=rs.getString(4);
	  String answer_3=rs.getString(5);
	  String answer_4=rs.getString(6);
	  int type_ques_no=rs.getInt(7);
	  int hint_id=rs.getInt(8);
	  String answer=rs.getString(9);
	  int mod_id=rs.getInt(10);
	  Createquestioncb u=new Createquestioncb(q_cb_id,question,answer_1,answer_2,answer_3,answer_4,type_ques_no,hint_id,answer,mod_id);
      u.setQ_cb_id(q_cb_id);
	  al.add(u);
  
  }
  return al;
}

public Collection<Createquestioncb> validate(int mod_id)throws SQLException
{
	 getquestionPstmt.setInt(1,mod_id );
	 
	 
	  ResultSet rs=getquestionPstmt.executeQuery();
	  Collection<Createquestioncb> al=new ArrayList<Createquestioncb>();
	 
	  while(rs.next())
	  {
		  int q_cb_id=rs.getInt(1);
		  String question=rs.getString(2);
		  String answer_1=rs.getString(3);
		  String answer_2=rs.getString(4);
		  String answer_3=rs.getString(5);
		  String answer_4=rs.getString(6);
		  int type_ques_no=rs.getInt(7);
		  int hint_id=rs.getInt(8);
		  String answer=rs.getString(9);
		  int mod_id1=rs.getInt(10);
		  Createquestioncb u=new Createquestioncb(q_cb_id,question,answer_1,answer_2,answer_3,answer_4,type_ques_no,hint_id,answer,mod_id1);
		  u.setQ_cb_id(q_cb_id);
		  al.add(u);
		  
	  }
	  return al;
}
public Createquestioncb getResult(String question)throws SQLException
{
	getresultPstmt.setString(1,question );
	 
	 
	  ResultSet rs=getresultPstmt.executeQuery();
	  //Collection<Createquestions> al=new ArrayList<Createquestions>();
	 //Createquestions u=new Createquestions();
	  if(rs.next())
	  {
		  int q_cb_id=rs.getInt(1);
		  String question1=rs.getString(2);
		  String answer_1=rs.getString(3);
		  String answer_2=rs.getString(4);
		  String answer_3=rs.getString(5);
		  String answer_4=rs.getString(6);
		  int type_ques_no=rs.getInt(7);
		  int hint_id=rs.getInt(8);
		  String answer=rs.getString(9);
		  int mod_id=rs.getInt(10);
		  Createquestioncb u=new Createquestioncb(q_cb_id,question1,answer_1,answer_2,answer_3,answer_4,type_ques_no,hint_id,answer,mod_id);
		  u.setQ_cb_id(q_cb_id);
		  return u;  
		  
	  }
	  else
		  return null;
  }
public Createquestioncb getAnswer(int q_cb_id)throws SQLException
{
	  getanswerPstmt.setInt(1,q_cb_id);
	  
	  ResultSet rs=getanswerPstmt.executeQuery();
	  if(rs.next())
	  {
		  
		  int q_cb_id1=rs.getInt(1);
		  String question1=rs.getString(2);
		  String answer_1=rs.getString(3);
		  String answer_2=rs.getString(4);
		  String answer_3=rs.getString(5);
		  String answer_4=rs.getString(6);
		  int type_ques_no=rs.getInt(7);
		  int hint_id=rs.getInt(8);
		  String answer=rs.getString(9);
		  int mod_id=rs.getInt(10);
		  
		  Createquestioncb c=new Createquestioncb(q_cb_id,question1,answer_1,answer_2,answer_3,answer_4,type_ques_no,hint_id,answer,mod_id);
		  c.setQ_cb_id(q_cb_id1);
		  return c;
		  
	  }
	  else
	  {
		  return null;
	  }
}
public void update(Createquestioncb u)throws SQLException
{
	  editquestionPstmt.setInt(7, u.getQ_cb_id());
	 
	  	 
	  editquestionPstmt.setString(1,u.getQuestion());
	  editquestionPstmt.setString(2, u.getAnswer_1());

	  editquestionPstmt.setString(3,u.getAnswer_2());
	  editquestionPstmt.setString(4, u.getAnswer_3());

	  editquestionPstmt.setString(5,u.getAnswer_4());
	  editquestionPstmt.setString(6, u.getAnswer());
	  editquestionPstmt.executeUpdate();
	  
	  
}

public Createquestioncb quesdetails(int q_cb_id)throws SQLException
{
	 getquestiondetailsPstmt.setInt(1,q_cb_id );
	 
	 
	  ResultSet rs=getquestiondetailsPstmt.executeQuery();
	  Collection<Createquestioncb> al=new ArrayList<Createquestioncb>();
	 
	  if(rs.next())
	  {
		  int q_cb_id1=rs.getInt(1);
		  String question1=rs.getString(2);
		  String answer_1=rs.getString(3);
		  String answer_2=rs.getString(4);
		  String answer_3=rs.getString(5);
		  String answer_4=rs.getString(6);
		  int type_ques_no=rs.getInt(7);
		  int hint_id=rs.getInt(8);
		  String answer=rs.getString(9);
		  int mod_id=rs.getInt(10);
		  Createquestioncb u=new Createquestioncb(q_cb_id1,question1,answer_1,answer_2,answer_3,answer_4,type_ques_no,hint_id,answer,mod_id);
		  u.setQ_cb_id(q_cb_id);
		  return u;   
	  }
	  else
	  {
		  return null;
	  }
}



}


