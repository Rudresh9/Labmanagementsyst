package model;

public class Createquestionta {
	
	private int q_txt_id;
	private String question;
	private String valid_answer;
	private int type_ques_no;
	private int hint_id;
	private int mod_id;
	
	public Createquestionta(int q_txt_id, String question, String valid_answer, int type_ques_no, int hint_id, int mod_id ) {
		super();
				
		this.q_txt_id = q_txt_id;
		this.question = question;
		this.valid_answer = valid_answer;
		this.type_ques_no = type_ques_no;
		this.hint_id = hint_id;
		this.mod_id = mod_id;
	}

	public int getQ_txt_id() {
		return q_txt_id;
	}

	public void setQ_txt_id(int q_txt_id) {
		this.q_txt_id = q_txt_id;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getValid_answer() {
		return valid_answer;
	}

	public void setValid_answer(String valid_answer) {
		this.valid_answer = valid_answer;
	}

	public int getType_ques_no() {
		return type_ques_no;
	}

	public void setType_ques_no(int type_ques_no) {
		this.type_ques_no = type_ques_no;
	}

	public int getHint_id() {
		return hint_id;
	}

	public void setHint_id(int hint_id) {
		this.hint_id = hint_id;
	}

	public int getMod_id() {
		return mod_id;
	}

	public void setMod_id(int mod_id) {
		this.mod_id = mod_id;
	}

	public Createquestionta() {
		super();
	}



	
	
}
