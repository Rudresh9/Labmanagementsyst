package model;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.*;


/**
 * Servlet implementation class AddquestionServlet
 */
@WebServlet("/EditquestioncbServlet")
public class EditquestioncbServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditquestioncbServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
			}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		String strmod_id=request.getParameter("chapid").trim();
		//String strquestionno=request.getParameter("questionno").trim();
		String strq_cb_id=request.getParameter("Q#").trim();
		String strquestion=request.getParameter("question").trim().toUpperCase();
		String stranswer_1=request.getParameter("option1").trim().toUpperCase();
		String stranswer_2=request.getParameter("option2").trim().toUpperCase();
		String stranswer_3=request.getParameter("option3").trim().toUpperCase();
		String stranswer_4=request.getParameter("option4").trim().toUpperCase();
		String strhint1=request.getParameter("hint1").trim().toUpperCase();
		String strhint2=request.getParameter("hint2").trim().toUpperCase();
		String strhint3=request.getParameter("hint3").trim().toUpperCase();
		String stranswer=request.getParameter("answer").trim().toLowerCase();
		
		//int questionno=Integer.parseInt(strquestionno);
		Dao dd= new Dao();
		int hint_id = dd.hintno();
	
		int mod_id=Integer.parseInt(strmod_id);
		int q_cb_id=Integer.parseInt(strq_cb_id);
		q_cb_id= 100*mod_id+q_cb_id;
		
		Createhint h =new Createhint(hint_id,strhint1,strhint2,strhint3);
		System.out.println("Hiint is--"+hint_id);	
		Createquestioncb u=new Createquestioncb(q_cb_id,strquestion,stranswer_1,stranswer_2,stranswer_3,stranswer_4,1,hint_id,stranswer,mod_id);
		//u.setQuestionno(questionno);
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try
		{
			HintDao da=new HintDao();
			da.create(h);
			QuestioncbDao dao=new QuestioncbDao();
			dao.create(u);
			
		    out.println("<B>QUESTION ADDED SUCCESSFULLY");
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			out.println("<B>"+e.getMessage());
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
			out.println("<B>"+e.getMessage());
		}
		
		out.close();

	}	
		
}

