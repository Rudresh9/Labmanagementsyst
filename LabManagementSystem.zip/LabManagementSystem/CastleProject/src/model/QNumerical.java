package model;

public class QNumerical {
	
int	q_num_id;
String question;
float answer;
String	type_ques_no;
String	hint_id;
public int getQ_num_id() {
	return q_num_id;
}
public void setQ_num_id(int q_num_id) {
	this.q_num_id = q_num_id;
}
public String getQuestion() {
	return question;
}
public void setQuestion(String question) {
	this.question = question;
}
public float getAnswer() {
	return answer;
}
public void setAnswer(float answer) {
	this.answer = answer;
}
public String getType_ques_no() {
	return type_ques_no;
}
public void setType_ques_no(String type_ques_no) {
	this.type_ques_no = type_ques_no;
}
public String getHint_id() {
	return hint_id;
}
public void setHint_id(String hint_id) {
	this.hint_id = hint_id;
}





}
