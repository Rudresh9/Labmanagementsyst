package model;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import model.*;

public class TestDao {
	String Driver="com.mysql.jdbc.Driver";
	  String url="jdbc:mysql://localhost:3306/castleexpt";
	  String user="root";
	  String password="root";
private Connection con;
private PreparedStatement gettestPstmt,createtestPstmt,deletetestPstmt,viewtestPstmt,gettestidPstmt,validatePstmt;
private String gettestSql="SELECT TESTID,TESTNAME FROM TEST";
private String createtestSql="INSERT INTO TEST(TESTNAME)VALUES(?)";
private String deletetestSql="DELETE FROM TEST WHERE TESTID=?";
private String viewtestSql= "SELECT * FROM TEST";
private String gettestidSql="SELECT TESTID,TESTNAME FROM TEST WHERE TESTNAME=?";
private String validateSql="SELECT * FROM TEST WHERE TESTID=?";

public TestDao()throws ClassNotFoundException,SQLException
{
	  Class.forName(Driver);
	  con=DriverManager.getConnection(url, user, password);
	  gettestPstmt=con.prepareStatement(gettestSql);
	  createtestPstmt=con.prepareStatement(createtestSql);
	  deletetestPstmt=con.prepareStatement(deletetestSql);
	  viewtestPstmt=con.prepareStatement(viewtestSql);
	  validatePstmt=con.prepareStatement(validateSql);
	  gettestidPstmt=con.prepareStatement(gettestidSql);
}
public Collection<Test>getAllTest()throws SQLException
{
	ResultSet rs=gettestPstmt.executeQuery();
	  Collection<Test> al=new ArrayList<Test>();
	  while(rs.next())
	  {
		  int testid=rs.getInt(1);
		  String testname=rs.getString(2);
		
		
		  Test u=new Test(testname);
		  u.setTestid(testid);
	      al.add(u);
	  
	  }
	  return al;
	
}
public void create(Test u)throws SQLException
{
	  createtestPstmt.setString(1,u.getTestname());
	 
	  createtestPstmt.executeUpdate();
	  
}
public void delete(int testid)throws SQLException
{
		deletetestPstmt.setInt(1,testid);
		
		deletetestPstmt.executeUpdate();
		
}
public ArrayList view()throws SQLException
{
  ResultSet rs=viewtestPstmt.executeQuery();
  ArrayList<Test> al=new ArrayList<Test>();
  while(rs.next())
  {
	  int testid=rs.getInt(1);
	  String testname=rs.getString(2);
	  
	  Test u=new Test(testname);
	  u.setTestid(testid);
      al.add(u);
  
  }
  return al;
}
public Test validate(String testname)throws SQLException
{
	
	  gettestidPstmt.setString(1,testname );

	  ResultSet rs=gettestidPstmt.executeQuery();
	  if(rs.next())
	  {
		  int testid=rs.getInt(1);
		  String testname1=rs.getString(2);
		
		  Test a=new Test(testname1);
		  a.setTestid(testid);
		  return a;
	  }
	  else
	  {
		  return null;
	  }
}

public boolean validatedelete(int testid)throws SQLException
{
	validatePstmt.setInt(1, testid);
	ResultSet rs=validatePstmt.executeQuery();
	if(rs.next())
	{
		return true;
		
	}
	else
	{
		return false;
	}
}

}

