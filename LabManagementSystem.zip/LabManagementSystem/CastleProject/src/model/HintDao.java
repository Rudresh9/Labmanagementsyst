package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import controller.*;
import model.*;

public class HintDao {
	String Driver="com.mysql.jdbc.Driver";
	  String url="jdbc:mysql://localhost:3306/castleexpt";
	  String user="root";
	  String password="root";
private Connection con;
private PreparedStatement addhintPstmt,viewhintPstmt,gethintPstmt,edithintPstmt;
private String addhintSql="INSERT INTO questions_hints(hint_id,hint_1,hint_2,hint_3)VALUES(?,?,?,?)";
private String viewhintSql="SELECT * FROM questions_hints";
private String gethintSql="SELECT * FROM questions_hints WHERE hint_id=?";
private String edithintSql="UPDATE questions_hints SET hint_1=?,hint_2=?,hint_3=? WHERE hint_id=?";
//private String validateSql="SELECT FIRSTNAME,LASTNAME,EMAILID,GENDER,ADDRESS,CITY,STATE,PIN,INSTITUTENAME,DEGREE,YEAROFPASSING,USERNAME,PASSWORD,USERID FROM USERTABLE WHERE USERNAME=? AND PASSWORD=?";
public HintDao()throws ClassNotFoundException,SQLException
{
	  Class.forName(Driver);
	  con=DriverManager.getConnection(url, user, password);
	  addhintPstmt=con.prepareStatement(addhintSql);
	  viewhintPstmt=con.prepareStatement(viewhintSql);
	  gethintPstmt=con.prepareStatement(gethintSql);
	 
	  edithintPstmt=con.prepareStatement(edithintSql);
	  //validatePstmt=con.prepareStatement(validateSql);
     
}
public void create(Createhint u)throws SQLException
{
	  addhintPstmt.setInt(1,u.getHint_id());
	  addhintPstmt.setString(2, u.getHint_1());
	  addhintPstmt.setString(3, u.getHint_2());
	  addhintPstmt.setString(4, u.getHint_3());
	  
	  addhintPstmt.executeUpdate();
	  
}
public ArrayList view()throws SQLException
{
  ResultSet rs=viewhintPstmt.executeQuery();
  ArrayList<Createhint> al=new ArrayList<Createhint>();
  while(rs.next())
  {
	  int hint_id=rs.getInt(1);
	  String hint_1=rs.getString(2);
	  String hint_2=rs.getString(3);
	  String hint_3=rs.getString(4);
	  
	  Createhint u=new Createhint(hint_id,hint_1,hint_2,hint_3);
      u.setHint_id(hint_id);
	  al.add(u);
  
  }
  return al;
}




public void update(Createhint u)throws SQLException
{
	  edithintPstmt.setInt(4, u.getHint_id());
	 
	  	 
	  edithintPstmt.setString(1,u.getHint_1());
	  edithintPstmt.setString(2, u.getHint_2());
	  edithintPstmt.setString(3, u.getHint_3());

	  
	  edithintPstmt.executeUpdate();
	  
	  
}

public Createhint gethint(int hint_id)throws SQLException
{
	 gethintPstmt.setInt(1,hint_id );
	 
	 
	  ResultSet rs=gethintPstmt.executeQuery();
	  Collection<Createhint> al=new ArrayList<Createhint>();
	 
	  if(rs.next())
	  {
		  int hint_id1=rs.getInt(1);
		  String hint_1=rs.getString(2);
		  String hint_2=rs.getString(3);
		  String hint_3=rs.getString(4);
		   Createhint u=new Createhint(hint_id1,hint_1,hint_2,hint_3);
		  u.setHint_id(hint_id);
		  return u;   
	  }
	  else
	  {
		  return null;
	  }
}



}


