package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import controller.User;
import model.Assignment;

public class LeftassDao {
	String Driver="com.mysql.jdbc.Driver";
	  String url="jdbc:mysql://localhost:3306/castleexpt";
	  String user="root";
	  String password="root";
private Connection con;
private PreparedStatement viewquestionPstmt;
private String viewquestionSql="SELECT * FROM asslcheck";

//private String validateSql="SELECT FIRSTNAME,LASTNAME,EMAILID,GENDER,ADDRESS,CITY,STATE,PIN,INSTITUTENAME,DEGREE,YEAROFPASSING,USERNAME,PASSWORD,USERID FROM USERTABLE WHERE USERNAME=? AND PASSWORD=?";
public LeftassDao()throws ClassNotFoundException,SQLException
{
	  Class.forName(Driver);
	  con=DriverManager.getConnection(url, user, password);
	  
	  viewquestionPstmt=con.prepareStatement(viewquestionSql);
	  
}

public ArrayList view()throws SQLException
{
  ResultSet rs=viewquestionPstmt.executeQuery();
  ArrayList<Leftass> al=new ArrayList<Leftass>();
  while(rs.next())
  {
	  
	  String netid=rs.getString(1);
	 
	  int expno=rs.getInt(2);
	
	  Leftass u=new Leftass(netid,expno);
      u.setExpno(expno);
	  al.add(u);
  
  }
  return al;
}





}


