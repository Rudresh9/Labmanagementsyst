package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import controller.User;
import model.Assignment;

public class CheckansDao {
	String Driver="com.mysql.jdbc.Driver";
	  String url="jdbc:mysql://localhost:3306/castleexpt";
	  String user="root";
	  String password="root";
private Connection con;
private PreparedStatement viewquestionPstmt;
private String viewquestionSql="SELECT * FROM checkans WHERE netid=? AND expno=? ";

//private String validateSql="SELECT FIRSTNAME,LASTNAME,EMAILID,GENDER,ADDRESS,CITY,STATE,PIN,INSTITUTENAME,DEGREE,YEAROFPASSING,USERNAME,PASSWORD,USERID FROM USERTABLE WHERE USERNAME=? AND PASSWORD=?";
public CheckansDao()throws ClassNotFoundException,SQLException
{
	  Class.forName(Driver);
	  con=DriverManager.getConnection(url, user, password);
	  
	  viewquestionPstmt=con.prepareStatement(viewquestionSql);
	  
}

public ArrayList view(String netid,int expno)throws SQLException
{
	viewquestionPstmt.setString(1,netid );
	viewquestionPstmt.setInt(2,expno );
  ResultSet rs=viewquestionPstmt.executeQuery();
  ArrayList<Checkans> al=new ArrayList<Checkans>();
  while(rs.next())
  {
	  String netid1 = rs.getString(1);
	  int expno1 = rs.getInt(2);
	  int quesno=rs.getInt(3);
	  String ans=rs.getString(4);
	
	  Checkans u=new Checkans(netid1,expno1,quesno,ans);
      u.setExpno(expno1);
	  al.add(u);
  
  }
  return al;
}





}


