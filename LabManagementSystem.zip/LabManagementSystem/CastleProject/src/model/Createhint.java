package model;

public class Createhint {
	
	private int hint_id;
	private String hint_1;
	private String hint_2;
	private String hint_3;
	
	public Createhint(int hint_id, String hint_1,String hint_2, String hint_3) {
		super();
		
		this.hint_id = hint_id;
		this.hint_1 = hint_1;
		this.hint_2 = hint_2;
		this.hint_3 = hint_3;
	}

	public int getHint_id() {
		return hint_id;
	}

	public void setHint_id(int hint_id) {
		this.hint_id = hint_id;
	}

	public String getHint_1() {
		return hint_1;
	}

	public void setHint_1(String hint_1) {
		this.hint_1 = hint_1;
	}

	public String getHint_2() {
		return hint_2;
	}

	public void setHint_2(String hint_2) {
		this.hint_2 = hint_2;
	}

	public String getHint_3() {
		return hint_3;
	}

	public void setHint_3(String hint_3) {
		this.hint_3 = hint_3;
	}

	
}
