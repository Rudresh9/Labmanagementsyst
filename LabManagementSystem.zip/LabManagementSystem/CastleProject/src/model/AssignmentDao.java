package model;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import model.Assignment;
//import org.dao.admin.Admin;
//import org.dao.setquestions.Createquestions;

public class AssignmentDao {
	String Driver="com.mysql.jdbc.Driver";
	  String url="jdbc:mysql://localhost:3306/castleexpt";
	  String user="root";
	  String password="root";
private Connection con;
private PreparedStatement getAssignmentPstmt,createAssignmentPstmt,deleteAssignmentPstmt,viewAssignmentPstmt,getexpnoPstmt,validatePstmt;
private String getAssignmentSql="SELECT expno,expname,intromsg FROM expdet";
private String createAssignmentSql="INSERT INTO expdet(expno,expname,intromsg)VALUES(?,?,?)";
private String deleteAssignmentSql="DELETE FROM expdet WHERE expno=?";
private String viewAssignmentSql= "SELECT * FROM expdet";
private String getexpnoSql="SELECT expno,expname,intromsg FROM expdet WHERE expname=? AND intromsg=?";
private String validateSql="SELECT * FROM expdet WHERE expno=?";

public AssignmentDao()throws ClassNotFoundException,SQLException
{
	  Class.forName(Driver);
	  con=DriverManager.getConnection(url, user, password);
	  getAssignmentPstmt=con.prepareStatement(getAssignmentSql);
	  createAssignmentPstmt=con.prepareStatement(createAssignmentSql);
	  deleteAssignmentPstmt=con.prepareStatement(deleteAssignmentSql);
	  viewAssignmentPstmt=con.prepareStatement(viewAssignmentSql);
	  validatePstmt=con.prepareStatement(validateSql);
	  getexpnoPstmt=con.prepareStatement(getexpnoSql);
}
public Collection<Assignment>getAllAssignment()throws SQLException
{
	ResultSet rs=getAssignmentPstmt.executeQuery();
	  Collection<Assignment> al=new ArrayList<Assignment>();
	  while(rs.next())
	  {
		  int expno=rs.getInt(1);
		  String expname=rs.getString(2);
		  String intromsg=rs.getString(3);
		
		  Assignment u=new Assignment(expno,expname,intromsg);
		  u.setexpno(expno);
	      al.add(u);
	  
	  }
	  return al;
	
}
public void create(Assignment u)throws SQLException
{
	createAssignmentPstmt.setInt(1,u.getexpno());
	  createAssignmentPstmt.setString(2,u.getexpname());
	  createAssignmentPstmt.setString(3, u.getintromsg());
	  createAssignmentPstmt.executeUpdate();
	  
}
public void delete(int expno)throws SQLException
{
		deleteAssignmentPstmt.setInt(1,expno);
		
		deleteAssignmentPstmt.executeUpdate();
		
}
public ArrayList view()throws SQLException
{
  ResultSet rs=viewAssignmentPstmt.executeQuery();
  ArrayList<Assignment> al=new ArrayList<Assignment>();
  while(rs.next())
  {
	  int expno=rs.getInt(1);
	  String expname=rs.getString(2);
	  String intromsg=rs.getString(3);
	  Assignment u=new Assignment(expno,expname,intromsg);
	  u.setexpno(expno);
      al.add(u);
  
  }
  return al;
}
public Assignment validate(String expname,String intromsg)throws SQLException
{
	
	  getexpnoPstmt.setString(1,expname );
	  getexpnoPstmt.setString(2, intromsg);
	  ResultSet rs=getexpnoPstmt.executeQuery();
	  if(rs.next())
	  {
		  int expno=rs.getInt(1);
		  String expname1=rs.getString(2);
		  String intromsg1=rs.getString(3);
		  Assignment a=new Assignment(expno,expname1,intromsg1);
		  a.setexpno(expno);
		  return a;
	  }
	  else
	  {
		  return null;
	  }
}

public boolean validatedelete(int expno)throws SQLException
{
	validatePstmt.setInt(1, expno);
	ResultSet rs=validatePstmt.executeQuery();
	if(rs.next())
	{
		return true;
		
	}
	else
	{
		return false;
	}
}

}
