package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import controller.User;
import model.Assignment;

public class QuestiontaDao {
	String Driver="com.mysql.jdbc.Driver";
	  String url="jdbc:mysql://localhost:3306/castleexpt";
	  String user="root";
	  String password="root";
private Connection con;
private PreparedStatement getanswerPstmt,addquestionPstmt,viewquestionPstmt,updatequestionPstmt,getquestionPstmt,getresultPstmt,editquestionPstmt,getquestiondetailsPstmt;
private String addquestionSql="INSERT INTO questextarea(q_txt_id,question,valid_answer,type_ques_no,hint_id,mod_id)VALUES(?,?,?,?,?,?)";
private String viewquestionSql="SELECT * FROM questextarea";
private String getquestionSql="SELECT mod_id,q_txt_id,question,valid_answer,type_ques_no FROM questiontextarea WHERE mod_id=?";
private String getresultSql="SELECT * FROM questextarea WHERE question=?";
private String getquestiondetailsSql="SELECT * FROM questextarea WHERE q_txt_id=?";
private String getanswerSql="SELECT mod_id,q_txt_id,question,uplimit,lowlimit,valid_answer FROM questextarea WHERE q_txt_id=?";
private String editquestionSql="UPDATE questextarea SET question=?,valid_answer=? WHERE q_txt_id=?";
//private String validateSql="SELECT FIRSTNAME,LASTNAME,EMAILID,GENDER,ADDRESS,CITY,STATE,PIN,INSTITUTENAME,DEGREE,YEAROFPASSING,USERNAME,PASSWORD,USERID FROM USERTABLE WHERE USERNAME=? AND PASSWORD=?";
public QuestiontaDao()throws ClassNotFoundException,SQLException
{
	  Class.forName(Driver);
	  con=DriverManager.getConnection(url, user, password);
	  addquestionPstmt=con.prepareStatement(addquestionSql);
	  viewquestionPstmt=con.prepareStatement(viewquestionSql);
	  getquestionPstmt=con.prepareStatement(getquestionSql);
	  getresultPstmt=con.prepareStatement(getresultSql);
	  getanswerPstmt=con.prepareStatement(getanswerSql);
	  editquestionPstmt=con.prepareStatement(editquestionSql);
	  //validatePstmt=con.prepareStatement(validateSql);
      getquestiondetailsPstmt=con.prepareStatement(getquestiondetailsSql);	  
}
public void create(Createquestionta u)throws SQLException
{
	  addquestionPstmt.setInt(1,u.getQ_txt_id());
	  addquestionPstmt.setString(2, u.getQuestion());
	  addquestionPstmt.setString(3, u.getValid_answer());
	  addquestionPstmt.setInt(4, u.getType_ques_no());
	  addquestionPstmt.setInt(5, u.getHint_id());
	  addquestionPstmt.setInt(6, u.getMod_id());
	  
	  
	  addquestionPstmt.executeUpdate();
	  
}
public ArrayList view()throws SQLException
{
  ResultSet rs=viewquestionPstmt.executeQuery();
  ArrayList<Createquestionta> al=new ArrayList<Createquestionta>();
  while(rs.next())
  {
	  int q_txt_id=rs.getInt(1);
	  String question=rs.getString(2);
	  String valid_answer=rs.getString(3);
	  int type_ques_no=rs.getInt(4);
	  int hint_id=rs.getInt(5);
	  int mod_id=rs.getInt(6);
	  
	  Createquestionta u=new Createquestionta(q_txt_id,question,valid_answer,type_ques_no,hint_id,mod_id);
      u.setQ_txt_id(q_txt_id);
	  al.add(u);
  
  }
  return al;
}

public Collection<Createquestionta> validate(int mod_id)throws SQLException
{
	 getquestionPstmt.setInt(1,mod_id );
	 
	 
	  ResultSet rs=getquestionPstmt.executeQuery();
	  Collection<Createquestionta> al=new ArrayList<Createquestionta>();
	 
	  while(rs.next())
	  {
		  int q_txt_id=rs.getInt(1);
		  String question=rs.getString(2);
		  String valid_answer=rs.getString(3);
		  int type_ques_no=rs.getInt(4);
		  int hint_id=rs.getInt(5);
		  int mod_id1=rs.getInt(6);
	
		  Createquestionta u=new Createquestionta(q_txt_id,question,valid_answer,type_ques_no,hint_id,mod_id1);
	      u.setQ_txt_id(q_txt_id);
		  al.add(u);
		  
	  }
	  return al;
}
public Createquestionta getResult(String question)throws SQLException
{
	getresultPstmt.setString(1,question );
	 
	 
	  ResultSet rs=getresultPstmt.executeQuery();
	  //Collection<Createquestions> al=new ArrayList<Createquestions>();
	 //Createquestions u=new Createquestions();
	  if(rs.next())
	  {
		  int q_txt_id=rs.getInt(1);
		  String question1=rs.getString(2);
		  String valid_answer=rs.getString(3);
		  int type_ques_no=rs.getInt(4);
		  int hint_id=rs.getInt(5);
		  int mod_id=rs.getInt(6);
		  Createquestionta u=new Createquestionta(q_txt_id,question,valid_answer,type_ques_no,hint_id,mod_id);
	      u.setQ_txt_id(q_txt_id);
		  return u;
		  
	  }
	  else
		  return null;
  }
public Createquestionta getAnswer(int q_txt_id)throws SQLException
{
	  getanswerPstmt.setInt(1,q_txt_id);
	  
	  ResultSet rs=getanswerPstmt.executeQuery();
	  if(rs.next())
	  {
		  
		  int q_txt_id1=rs.getInt(1);
		  String question=rs.getString(2);
		  String valid_answer=rs.getString(3);
		  int type_ques_no=rs.getInt(4);
		  int hint_id=rs.getInt(5);
		  int mod_id=rs.getInt(6);
		 
		  Createquestionta c=new Createquestionta(q_txt_id1,question,valid_answer,type_ques_no,hint_id,mod_id);
	      c.setQ_txt_id(q_txt_id);
		 
		  return c;
		  
	  }
	  else
	  {
		  return null;
	  }
}
public void update(Createquestionta u)throws SQLException
{
	  editquestionPstmt.setInt(3, u.getQ_txt_id());
	 
	  	 
	  editquestionPstmt.setString(1,u.getQuestion());
	 
	  editquestionPstmt.setString(2, u.getValid_answer());

	  
	  editquestionPstmt.executeUpdate();
	  
	  
}

public Createquestionta quesdetails(int q_txt_id)throws SQLException
{
	 getquestiondetailsPstmt.setInt(1,q_txt_id );
	 
	 
	  ResultSet rs=getquestiondetailsPstmt.executeQuery();
	  Collection<Createquestionta> al=new ArrayList<Createquestionta>();
	 
	  if(rs.next())
	  {
		  int q_txt_id1=rs.getInt(1);
		  String question=rs.getString(2);
		  String valid_answer=rs.getString(3);
		  int type_ques_no=rs.getInt(4);
		  int hint_id=rs.getInt(5);
		  int mod_id=rs.getInt(6);
		
		  Createquestionta u=new Createquestionta(q_txt_id1,question,valid_answer,type_ques_no,hint_id,mod_id);
	      u.setQ_txt_id(q_txt_id);
		 
		  return u;  
	  }
	  else
	  {
		  return null;
	  }
}



}


