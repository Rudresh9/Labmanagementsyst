package model;

public class QcheckBox {
	
int	q_cb_id;
String	question,answer,answera,answerb,answerc,answerd,type_ques_no;
String hint1,hint2,hint3;




public int getQ_cb_id() {
	return q_cb_id;
}
public void setQ_cb_id(int q_cb_id) {
	this.q_cb_id = q_cb_id;
}
public String getQuestion() {
	return question;
}
public void setQuestion(String question) {
	this.question = question;
}
public String getAnswer() {
	return answer;
}
public void setAnswer(String answer) {
	this.answer = answer;
}
public String getAnswera() {
	return answera;
}
public void setAnswera(String answera) {
	this.answera = answera;
}
public String getAnswerb() {
	return answerb;
}
public void setAnswerb(String answerb) {
	this.answerb = answerb;
}
public String getAnswerc() {
	return answerc;
}
public void setAnswerc(String answerc) {
	this.answerc = answerc;
}
public String getAnswerd() {
	return answerd;
}
public void setAnswerd(String answerd) {
	this.answerd = answerd;
}
public String getType_ques_no() {
	return type_ques_no;
}
public void setType_ques_no(String type_ques_no) {
	this.type_ques_no = type_ques_no;
}
public String getHint1() {
	return hint1;
}
public void setHint1(String hint1) {
	this.hint1 = hint1;
}
public String getHint2() {
	return hint2;
}
public void setHint2(String hint2) {
	this.hint2 = hint2;
}
public String getHint3() {
	return hint3;
}
public void setHint3(String hint3) {
	this.hint3 = hint3;
}

}
