package model;



public class Assignment {
    private int expno;
    
	public int getexpno() {
		return expno;
	}
	public void setexpno(int expno) {
		this.expno = expno;
	}
	private String expname;
	private String intromsg;
	public Assignment(int expno,String expname, String intromsg) {
		super();
		this.expno = expno;
		this.expname = expname;
		this.intromsg = intromsg;
	}
	public Assignment() {
		super();
	}
	public String getexpname() {
		return expname;
	}
	public void setexpname(String expname) {
		this.expname = expname;
	}
	public String getintromsg() {
		return intromsg;
	}
	public void setintromsg(String intromsg) {
		this.intromsg = intromsg;
	}
	

}
