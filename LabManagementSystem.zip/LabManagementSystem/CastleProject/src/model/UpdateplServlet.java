package model;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.*;
import model.*;

/**
 * Servlet implementation class UpdatequestionServlet
 */
@WebServlet("/UpdateplServlet")
public class UpdateplServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateplServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	int quesno=Integer.parseInt(request.getParameter("quesno").trim());
	int expno=Integer.parseInt(request.getParameter("expno").trim());
	String question=request.getParameter("question");
	String valid_answer=request.getParameter("valid_answer");

	

	Createquestionpl u=new Createquestionpl(expno,quesno,question,valid_answer);
	
	u.setQuesno(quesno);
	Questionpldao dao;
	
	
	 response.setContentType("text/html");
     PrintWriter out=response.getWriter();

	try {
		dao = new Questionpldao();
		
		dao.update(u);
		out.println("<B><a href=editqta.jsp>Question changed...GO BACK</a>");
	} 
	catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}

}
