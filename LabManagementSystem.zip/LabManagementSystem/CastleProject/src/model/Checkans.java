package model;

public class Checkans {
	private String netid;
	private int expno;
	private int quesno;
	private String ans;
	
	public Checkans(String netid,int expno,int quesno,String ans){
		super();
		
		this.netid = netid;
		this.expno = expno;
		this.quesno = quesno;
		this.ans = ans;
		
	}
	
	public Checkans(){
		super();
	}

	public int getQuesno() {
		return quesno;
	}

	public void setQuesno(int quesno) {
		this.quesno = quesno;
	}

	public String getAns() {
		return ans;
	}

	public void setAns(String ans) {
		this.ans = ans;
	}

	public String getNetid() {
		return netid;
	}

	public void setNetid(String netid) {
		this.netid = netid;
	}

	public int getExpno() {
		return expno;
	}

	public void setExpno(int expno) {
		this.expno = expno;
	}
	
}
