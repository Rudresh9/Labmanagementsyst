package model;

public class Checked {
	private String netid;
	private int expno;
	private int score;
	
	public Checked(String netid,int expno,int score){
		super();
		
		this.netid = netid;
		this.expno = expno;
		this.score = score;
		
	}
	
	public Checked(){
		super();
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getNetid() {
		return netid;
	}

	public void setNetid(String netid) {
		this.netid = netid;
	}

	public int getExpno() {
		return expno;
	}

	public void setExpno(int expno) {
		this.expno = expno;
	}
	
}
