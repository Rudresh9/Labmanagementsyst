package model;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.*;


/**
 * Servlet implementation class AddquestionServlet
 */
@WebServlet("/AddquestionplServlet")
public class AddquestionplServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddquestionplServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
			}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		String strmod_id=request.getParameter("chapid").trim();
		//String strquestionno=request.getParameter("questionno").trim();
		String strq_ta_id=request.getParameter("Q#").trim();
		String strquestion=request.getParameter("question").trim().toUpperCase();
		String strvalid_answer=request.getParameter("valid_answer").trim().toUpperCase();
					
		//int questionno=Integer.parseInt(strquestionno);
		Dao dd= new Dao();
		
		int mod_id=Integer.parseInt(strmod_id);
		int x=dd.cq(mod_id) + 1;
		
		
		
		Createquestionpl u=new Createquestionpl(mod_id,x,strquestion,strvalid_answer);
		//u.setQuestionno(questionno);
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try
		{
			
			Questionpldao dao=new Questionpldao();
			dao.create(u);
			
		    out.println("<B>QUESTION ADDED SUCCESSFULLY");
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			out.println("<B>"+e.getMessage());
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
			out.println("<B>"+e.getMessage());
		}
		
		out.close();

	}	
		
}

