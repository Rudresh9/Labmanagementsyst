package model;

public class PreLab {

	private String moduleName;
	private String objectie;
	private String hypothesis;
	private String variables;
	private String experimental;
	private String chemical;
	public String getObjectie() {
		return objectie;
	}
	public void setObjectie(String objectie) {
		this.objectie = objectie;
	}
	public String getHypothesis() {
		return hypothesis;
	}
	public void setHypothesis(String hypothesis) {
		this.hypothesis = hypothesis;
	}
	public String getVariables() {
		return variables;
	}
	public void setVariables(String variables) {
		this.variables = variables;
	}
	public String getExperimental() {
		return experimental;
	}
	public void setExperimental(String experimental) {
		this.experimental = experimental;
	}
	public String getChemical() {
		return chemical;
	}
	public void setChemical(String chemical) {
		this.chemical = chemical;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	
	
}
