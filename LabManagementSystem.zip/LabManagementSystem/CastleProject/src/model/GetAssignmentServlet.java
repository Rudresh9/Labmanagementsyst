package model;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.dao.User;
//import org.dao.UserDAO;
import model.Assignment;
import model.AssignmentDao;

@WebServlet("/GetAssignmentServlet")
public class GetAssignmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetAssignmentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String expname=request.getParameter("expname");
		  String intromsg=request.getParameter("intromsg");
		 //response.setContentType("text/html");
	     // PrintWriter out=response.getWriter();
		  
		RequestDispatcher rdsuccess=request.getRequestDispatcher("/GetquestionServlet");
		 RequestDispatcher rderror=request.getRequestDispatcher("/ErrorServlet");
		  try
		  {
			 // UserDAO dao=new UserDAO();
			  //User u=dao.validate(username, password);
			   

			  AssignmentDao dao=new AssignmentDao();
			  Assignment u=dao.validate(expname, intromsg);
			  
			  if(u!=null)
			  {
				  
				 request.setAttribute("Ass",u);
				 request.setAttribute("NAME",u);
				 rdsuccess.forward(request, response);
				  }
			  else{
				  request.setAttribute("ERRMSG","INVALID AssignmentName OR Description");
				 rderror.forward(request, response);
		          }
			  } 
			  
		  
		  
		  catch(ClassNotFoundException e)
		  {
			 e.printStackTrace();
			
			 request.setAttribute("ERRMSG","CLASS LOADING ERROR"+e.getMessage());
			  rderror.forward(request, response);
		  }
		  catch(SQLException e)
		  {
			  e.printStackTrace();
			  request.setAttribute("ERRMSG","SQL ERROR"+e.getMessage());
			  rderror.forward(request, response);
			  
			
		  }
		  

		
		
	   }


		
		
	}


