package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import controller.User;
import model.Assignment;

public class PstlabDao {
	String Driver="com.mysql.jdbc.Driver";
	  String url="jdbc:mysql://localhost:3306/castleexpt";
	  String user="root";
	  String password="root";
private Connection con;
private PreparedStatement viewquestionPstmt;
private String viewquestionSql="SELECT * FROM postlab WHERE expno=? ";

//private String validateSql="SELECT FIRSTNAME,LASTNAME,EMAILID,GENDER,ADDRESS,CITY,STATE,PIN,INSTITUTENAME,DEGREE,YEAROFPASSING,USERNAME,PASSWORD,USERID FROM USERTABLE WHERE USERNAME=? AND PASSWORD=?";
public PstlabDao()throws ClassNotFoundException,SQLException
{
	  Class.forName(Driver);
	  con=DriverManager.getConnection(url, user, password);
	  
	  viewquestionPstmt=con.prepareStatement(viewquestionSql);
	  
}

public ArrayList view(int expno)throws SQLException
{
	
	viewquestionPstmt.setInt(1,expno );
  ResultSet rs=viewquestionPstmt.executeQuery();
  ArrayList<Pstlab> al=new ArrayList<Pstlab>();
  while(rs.next())
  {
	  
	  int expno1 = rs.getInt(1);
	  int quesno=rs.getInt(2);
	  String question = rs.getString(3);
	  String answer=rs.getString(4);
	
	  Pstlab u=new Pstlab(expno1,quesno,question,answer);
      u.setExpno(expno1);
	  al.add(u);
  
  }
  return al;
}





}


