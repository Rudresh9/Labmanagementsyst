package model;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Assignment;
import model.AssignmentDao;

//import org.dao.chapter.Chapter;
//import org.dao.chapter.ChapterDAO;
//import org.dao.setquestions.Createquestions;
//import org.dao.setquestions.QuestionDAO;

/**
 * Servlet implementation class CreatechapterServlet
 */
@WebServlet("/CreateAssignmentServlet")
public class CreateAssignmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateAssignmentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request,response);
		String strexpname=request.getParameter("expname");
		//strchaptername.toUpperCase();
		String strintromsg=request.getParameter("intromsg");
		
		
		request.setAttribute("expname", strexpname);
		request.setAttribute("intromsg", strintromsg);
		
		Dao dd = new Dao();
		
		int expno = dd.expno();
		//ahi expno lavo
		Assignment u=new Assignment(expno,strexpname,strintromsg);
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try
		{
			AssignmentDao dao=new AssignmentDao();
			dao.create(u);
			dd.initiatestatususer(strexpname, strintromsg);
		    out.println("<B>Assignment ADDED SUCCESSFULLY<br>");
		    out.println("<B><a href=AssignmentmanagementServlet>CLICK HERE TO GO BACK</a>");
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			out.println("<B>"+e.getMessage());
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
			out.println("<B>"+e.getMessage());
		}
		out.close();
	}
		
	}


