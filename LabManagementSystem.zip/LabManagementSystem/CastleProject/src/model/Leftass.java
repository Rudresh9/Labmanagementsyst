package model;

public class Leftass {
	private String netid;
	private int expno;
	
	public Leftass(String netid,int expno){
		super();
		
		this.netid = netid;
		this.expno = expno;
		
	}
	
	public Leftass(){
		super();
	}

	public String getNetid() {
		return netid;
	}

	public void setNetid(String netid) {
		this.netid = netid;
	}

	public int getExpno() {
		return expno;
	}

	public void setExpno(int expno) {
		this.expno = expno;
	}
	
}
