package model;



public class Test {
    private int testid;
    
	public int getTestid() {
		return testid;
	}
	public void setTestid(int testid) {
		this.testid = testid;
	}
	private String testname;
	
	public Test(String testname) {
		super();
		
		this.testname = testname;
		
	}
	public Test() {
		super();
	}
	public String getTestname() {
		return testname;
	}
	public void setTestname(String testname) {
		this.testname = testname;
	}

	

}