package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import controller.User;
import model.Assignment;

public class Questionpldao {
	String Driver="com.mysql.jdbc.Driver";
	  String url="jdbc:mysql://localhost:3306/castleexpt";
	  String user="root";
	  String password="root";
private Connection con;
private PreparedStatement getanswerPstmt,addquestionPstmt,viewquestionPstmt,updatequestionPstmt,getquestionPstmt,getresultPstmt,editquestionPstmt,getquestiondetailsPstmt;
private String addquestionSql="INSERT INTO postlab(expno,quesno,ques,ans)VALUES(?,?,?,?)";
private String viewquestionSql="SELECT * FROM postlab";
private String getquestionSql="SELECT expno,quesno,ques,ans FROM postlab WHERE expno=?";
private String getresultSql="SELECT * FROM postlab WHERE ques=?";
private String getquestiondetailsSql="SELECT * FROM postlab WHERE expno=?";
private String getanswerSql="SELECT expno,quesno,ques,ans FROM postlab WHERE expno=?";
private String editquestionSql="UPDATE postlab SET ques=?,ans=? WHERE expno=?";
//private String validateSql="SELECT FIRSTNAME,LASTNAME,EMAILID,GENDER,ADDRESS,CITY,STATE,PIN,INSTITUTENAME,DEGREE,YEAROFPASSING,USERNAME,PASSWORD,USERID FROM USERTABLE WHERE USERNAME=? AND PASSWORD=?";
public Questionpldao()throws ClassNotFoundException,SQLException
{
	  Class.forName(Driver);
	  con=DriverManager.getConnection(url, user, password);
	  addquestionPstmt=con.prepareStatement(addquestionSql);
	  viewquestionPstmt=con.prepareStatement(viewquestionSql);
	  getquestionPstmt=con.prepareStatement(getquestionSql);
	  getresultPstmt=con.prepareStatement(getresultSql);
	  getanswerPstmt=con.prepareStatement(getanswerSql);
	  editquestionPstmt=con.prepareStatement(editquestionSql);
	  //validatePstmt=con.prepareStatement(validateSql);
      getquestiondetailsPstmt=con.prepareStatement(getquestiondetailsSql);	  
}
public void create(Createquestionpl u)throws SQLException
{
	  addquestionPstmt.setInt(1,u.getExpno());
	  addquestionPstmt.setInt(2, u.getQuesno());
	  addquestionPstmt.setString(3, u.getQuestion());
	  addquestionPstmt.setString(4, u.getAns());
	
	  
	  
	  addquestionPstmt.executeUpdate();
	  
}
public ArrayList view()throws SQLException
{
  ResultSet rs=viewquestionPstmt.executeQuery();
  ArrayList<Createquestionpl> al=new ArrayList<Createquestionpl>();
  while(rs.next())
  {
	  int expno=rs.getInt(1);
	  int quesno = rs.getInt(2);
	  String question=rs.getString(3);
	  String ans=rs.getString(4);
	  
	  Createquestionpl u=new Createquestionpl(expno,quesno,question,ans);
      u.setQuesno(quesno);
	  al.add(u);
  
  }
  return al;
}

public Collection<Createquestionpl> validate(int expno)throws SQLException
{
	 getquestionPstmt.setInt(1,expno );
	 
	 
	  ResultSet rs=getquestionPstmt.executeQuery();
	  Collection<Createquestionpl> al=new ArrayList<Createquestionpl>();
	 
	  while(rs.next())
	  {
		  int expno1=rs.getInt(1);
		  int quesno = rs.getInt(2);
		  String question=rs.getString(3);
		  String ans=rs.getString(4);
		  	
		  Createquestionpl u=new Createquestionpl(expno1,quesno,question,ans);
	      u.setQuesno(quesno);
		  al.add(u);
		  
	  }
	  return al;
}
public Createquestionpl getResult(String question)throws SQLException
{
	getresultPstmt.setString(1,question );
	 
	 
	  ResultSet rs=getresultPstmt.executeQuery();
	  //Collection<Createquestions> al=new ArrayList<Createquestions>();
	 //Createquestions u=new Createquestions();
	  if(rs.next())
	  {
		  int expno=rs.getInt(1);
		  int quesno=rs.getInt(2);
		  String question1=rs.getString(3);
		  String ans=rs.getString(4);
		 
		  Createquestionpl u=new Createquestionpl(expno,quesno,question,ans);
	      u.setQuesno(quesno);
		  return u;
		  
	  }
	  else
		  return null;
  }
public Createquestionpl getAnswer(int quesno)throws SQLException
{
	  getanswerPstmt.setInt(1,quesno);
	  
	  ResultSet rs=getanswerPstmt.executeQuery();
	  if(rs.next())
	  {
		  
		  int expno=rs.getInt(1);
		  int quesno1=rs.getInt(2);
		  String question=rs.getString(3);
		  String ans=rs.getString(4);
		
		 
		  Createquestionpl c=new Createquestionpl(expno,quesno1,question,ans);
	      c.setQuesno(quesno);
		 
		  return c;
		  
	  }
	  else
	  {
		  return null;
	  }
}
public void update(Createquestionpl u)throws SQLException
{
	  editquestionPstmt.setInt(3, u.getQuesno());
	 
	  	 
	  editquestionPstmt.setString(1,u.getQuestion());
	 
	  editquestionPstmt.setString(2, u.getAns());

	  
	  editquestionPstmt.executeUpdate();
	  
	  
}

public Createquestionpl quesdetails(int quesno)throws SQLException
{
	 getquestiondetailsPstmt.setInt(1,quesno );
	 
	 
	  ResultSet rs=getquestiondetailsPstmt.executeQuery();
	  Collection<Createquestionta> al=new ArrayList<Createquestionta>();
	 
	  if(rs.next())
	  {
		  int expno=rs.getInt(1);
		  int quesno1=rs.getInt(2);
		  String question=rs.getString(3);
		  String ans=rs.getString(4);
		  
		
		  Createquestionpl u=new Createquestionpl(expno,quesno1,question,ans);
	      u.setQuesno(quesno);
		 
		  return u;  
	  }
	  else
	  {
		  return null;
	  }
}



}


