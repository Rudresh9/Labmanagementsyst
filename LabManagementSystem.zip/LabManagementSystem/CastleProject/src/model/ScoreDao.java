package model;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.*;

public class ScoreDao {
	String Driver="com.mysql.jdbc.Driver";
	  String url="jdbc:mysql://localhost:3306/castleexpt";
	  String user="root";
	  String password="root";
private Connection con;
private PreparedStatement createscorePstmt,viewscorePstmt;
 
private String createscoreSql="INSERT INTO SCORE(NETID,TESTID,SCORE)VALUES(?,?,?)";
private String viewscoreSql="SELECT * FROM SCORE ";
public ScoreDao()throws ClassNotFoundException,SQLException
{
	  Class.forName(Driver);
	  con=DriverManager.getConnection(url, user, password);
	  createscorePstmt=con.prepareStatement(createscoreSql);
	  viewscorePstmt=con.prepareStatement(viewscoreSql);
}
public void create(String netid,int testid,int score)throws SQLException
{
	  createscorePstmt.setString(1,netid);
	  createscorePstmt.setInt(2,testid);
	  createscorePstmt.setInt(3,score);
	  createscorePstmt.executeUpdate();
	  
}
public ArrayList<Score> display()throws SQLException
{
	  
			ResultSet rs=viewscorePstmt.executeQuery();
			  ArrayList<Score> al=new ArrayList<Score>();
			  while(rs.next())
			  {
				  String netid=rs.getString(1);
				  int testid = rs.getInt(2);
				  int score=rs.getInt(3);
				  Score u=new Score(netid,testid,score);
				  al.add(u);
               }
			  return al;
}
}
