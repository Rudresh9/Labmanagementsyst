package model;

public class Score {
	private String netid;
	private int testid;
	private int marks;
	public Score(String netid, int testid,int marks) {
		super();
		this.netid = netid;
		this.testid= testid;
		this.marks = marks;
	}
	public int getTestid() {
		return testid;
	}
	public void setTestid(int testid) {
		this.testid = testid;
	}
	public Score() {
		super();
	}
	
	public String getNetid() {
		return netid;
	}
	public void setNetid(String netid) {
		this.netid = netid;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	

}
