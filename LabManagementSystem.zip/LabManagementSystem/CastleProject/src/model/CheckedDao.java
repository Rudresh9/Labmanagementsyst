package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import controller.User;
import model.Assignment;

public class CheckedDao {
	String Driver="com.mysql.jdbc.Driver";
	  String url="jdbc:mysql://localhost:3306/castleexpt";
	  String user="root";
	  String password="root";
private Connection con;
private PreparedStatement viewquestionPstmt;
private String viewquestionSql="SELECT * FROM checked";

//private String validateSql="SELECT FIRSTNAME,LASTNAME,EMAILID,GENDER,ADDRESS,CITY,STATE,PIN,INSTITUTENAME,DEGREE,YEAROFPASSING,USERNAME,PASSWORD,USERID FROM USERTABLE WHERE USERNAME=? AND PASSWORD=?";
public CheckedDao()throws ClassNotFoundException,SQLException
{
	  Class.forName(Driver);
	  con=DriverManager.getConnection(url, user, password);
	  
	  viewquestionPstmt=con.prepareStatement(viewquestionSql);
	  
}

public ArrayList view()throws SQLException
{
	
  ResultSet rs=viewquestionPstmt.executeQuery();
  ArrayList<Checked> al=new ArrayList<Checked>();
  while(rs.next())
  {
	  String netid = rs.getString(1);
	  int expno = rs.getInt(2);
	  int score=rs.getInt(3);
	  	
	  Checked u=new Checked(netid,expno,score);
      u.setExpno(expno);
	  al.add(u);
  
  }
  return al;
}





}


