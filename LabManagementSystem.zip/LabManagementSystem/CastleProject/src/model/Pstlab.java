package model;

public class Pstlab {
	
	private int expno;
	private int quesno;
	private String question;
	private String answer;
	public Pstlab(int expno,int quesno,String question, String answer) {
		super();
		this.expno = expno;
		this.quesno= quesno;
		this.question = question;
		this.answer = answer;
	}
	
	public Pstlab() {
		super();
	}

	public int getExpno() {
		return expno;
	}

	public void setExpno(int expno) {
		this.expno = expno;
	}

	public int getQuesno() {
		return quesno;
	}

	public void setQuesno(int quesno) {
		this.quesno = quesno;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}
	


}
