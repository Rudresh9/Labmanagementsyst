package model;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.*;
import controller.*;

/**
 * Servlet implementation class GetresultServlet
 */
@WebServlet("/GetresultServlet")
public class GetresultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetresultServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		RequestDispatcher rd=request.getRequestDispatcher("/answer.jsp?");
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		String username = request.getParameter("username");
		String strtestid = request.getParameter("testid");
	
		int testid = Integer.parseInt(strtestid);
		Dao dd = new Dao();
		String Netid = dd.checknetid(username);
		System.out.println(username);
		
		Enumeration<String> coll=request.getParameterNames();
		
		
		//int coll1=Integer.parseInt(coll);
		ArrayList<String> attempted=new ArrayList<String>();
		while(coll.hasMoreElements())
		{
			String temp = coll.nextElement();
			System.out.println(temp+"    "+temp.equals("username") +"            "+ temp.equals("testid"));
			if(temp.equals("username") || temp.equals("testid"))
			{
				break;
			}
			else {
			attempted.add(temp);
			System.out.println(temp);
			}
			
		}
		ArrayList<String> attempted_answers=new ArrayList<String>();
		for(String q : attempted)
		{
			attempted_answers.add(request.getParameter(q));
				
		}
		int score=0,correct=0,wrong=0;
		try 
		{
			
			QuestionDao d=new QuestionDao();
			for(int i=0;i<attempted.size();i++){
				System.out.println(attempted.get(i));
				int ques=Integer.parseInt(attempted.get(i));
	            Createquestions cq=d.getAnswer(ques);
	            String given_ans=attempted_answers.get(i);
	            if (given_ans.equalsIgnoreCase(cq.getAnswer()))
	            {
	            	score++;
	            	correct++;
	            }else
	            {
	            	wrong++;
	            }
	            
	            //request.setAttribute("ANS",al);
				//1 rdsuccess.forward(request, response);
				
			}
			
			//int userid=Integer.parseInt(Netid);
			
			String strcorrect=String.valueOf(correct);
			String strwrong=String.valueOf(wrong);
			request.setAttribute("CORRECT", strcorrect);
			request.setAttribute("WRONG", strwrong);
			System.out.println(strcorrect);
			System.out.println(strwrong);
			rd.forward(request, response);
			//out.println("<b><h3>YOUR SCORE ="+score);
            //out.println("<b><h4>CORRECT ANSWERS ="+correct);
            //out.println("<b><h4>WRONG ANSWERS ="+wrong);
           
          //  out.println("<B><input type=submit value=TAKE ANOTHER TEST></input></B>");
            
            ScoreDao dao=new ScoreDao();
            dao.create(Netid, testid,score);
            int x = dd.updateTest(Netid,testid);
           // response.sendRedirect("HomepageServlet");
             
           // out.println("</form>");
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    //String name[]=request.getParameterNames();
		

		
    		
	
	}

}
