package model;

public class Createquestioncb {
	
	private int q_cb_id;
	private String question;
	private String answer_1;
	private String answer_2;
	private String answer_3;
	private String answer_4;
	private int type_ques_no;
	private int hint_id;
	private String answer;
	private int mod_id;
	
	public Createquestioncb(int q_cb_id, String question, String answer_1,
			String answer_2, String answer_3, String answer_4, int type_ques_no, int hint_id, String answer, int mod_id ) {
		super();
				
		this.q_cb_id = q_cb_id;
		this.question = question;
		this.answer_1 = answer_1;
		this.answer_2 = answer_2;
		this.answer_3 = answer_3;
		this.answer_4 = answer_4;
		this.type_ques_no = type_ques_no;
		this.hint_id = hint_id;
		this.answer = answer;
		this.mod_id = mod_id;
	}

	public Createquestioncb() {
		super();
	}

	public int getQ_cb_id() {
		return q_cb_id;
	}

	public void setQ_cb_id(int q_cb_id) {
		this.q_cb_id = q_cb_id;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer_1() {
		return answer_1;
	}

	public void setAnswer_1(String answer_1) {
		this.answer_1 = answer_1;
	}

	public String getAnswer_2() {
		return answer_2;
	}

	public void setAnswer_2(String answer_2) {
		this.answer_2 = answer_2;
	}

	public String getAnswer_3() {
		return answer_3;
	}

	public void setAnswer_3(String answer_3) {
		this.answer_3 = answer_3;
	}

	public String getAnswer_4() {
		return answer_4;
	}

	public void setAnswer_4(String answer_4) {
		this.answer_4 = answer_4;
	}

	public int getType_ques_no() {
		return type_ques_no;
	}

	public void setType_ques_no(int type_ques_no) {
		this.type_ques_no = type_ques_no;
	}

	public int getHint_id() {
		return hint_id;
	}

	public void setHint_id(int hint_id) {
		this.hint_id = hint_id;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public int getMod_id() {
		return mod_id;
	}

	public void setMod_id(int mod_id) {
		this.mod_id = mod_id;
	}

	
	
}
