package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import controller.User;
import model.Assignment;

public class QuestionnrDao {
	String Driver="com.mysql.jdbc.Driver";
	  String url="jdbc:mysql://localhost:3306/castleexpt";
	  String user="root";
	  String password="root";
private Connection con;
private PreparedStatement getanswerPstmt,addquestionPstmt,viewquestionPstmt,updatequestionPstmt,getquestionPstmt,getresultPstmt,editquestionPstmt,getquestiondetailsPstmt;
private String addquestionSql="INSERT INTO quesnumerical(q_num_id,question,valid_answer,type_ques_no,hint_id,mod_id,uplimit,lowlimit)VALUES(?,?,?,?,?,?,?,?)";
private String viewquestionSql="SELECT * FROM quesnumerical";
private String getquestionSql="SELECT mod_id,q_num_id,question,valid_answer,type_ques_no,uplimit,lowlimit FROM quesnumerical WHERE mod_id=?";
private String getresultSql="SELECT * FROM quesnumerical WHERE question=?";
private String getquestiondetailsSql="SELECT * FROM quesnumerical WHERE q_num_id=?";
private String getanswerSql="SELECT mod_id,q_num_id,question,uplimit,lowlimit,valid_answer FROM quesnumerical WHERE q_num_id=?";
private String editquestionSql="UPDATE quesnumerical SET question=?,uplimit=?,lowlimit=?,valid_answer=? WHERE q_num_id=?";
//private String validateSql="SELECT FIRSTNAME,LASTNAME,EMAILID,GENDER,ADDRESS,CITY,STATE,PIN,INSTITUTENAME,DEGREE,YEAROFPASSING,USERNAME,PASSWORD,USERID FROM USERTABLE WHERE USERNAME=? AND PASSWORD=?";
public QuestionnrDao()throws ClassNotFoundException,SQLException
{
	  Class.forName(Driver);
	  con=DriverManager.getConnection(url, user, password);
	  addquestionPstmt=con.prepareStatement(addquestionSql);
	  viewquestionPstmt=con.prepareStatement(viewquestionSql);
	  getquestionPstmt=con.prepareStatement(getquestionSql);
	  getresultPstmt=con.prepareStatement(getresultSql);
	  getanswerPstmt=con.prepareStatement(getanswerSql);
	  editquestionPstmt=con.prepareStatement(editquestionSql);
	  //validatePstmt=con.prepareStatement(validateSql);
      getquestiondetailsPstmt=con.prepareStatement(getquestiondetailsSql);	  
}
public void create(Createquestionnr u)throws SQLException
{
	  addquestionPstmt.setInt(1,u.getQ_num_id());
	  addquestionPstmt.setString(2, u.getQuestion());
	  addquestionPstmt.setInt(3, u.getValid_answer());
	  addquestionPstmt.setInt(4, u.getType_ques_no());
	  addquestionPstmt.setInt(5, u.getHint_id());
	  addquestionPstmt.setInt(6, u.getMod_id());
	  addquestionPstmt.setDouble(7, u.getUplimit());
	  addquestionPstmt.setDouble(8, u.getLowlimit());
	  
	  addquestionPstmt.executeUpdate();
	  
}
public ArrayList view()throws SQLException
{
  ResultSet rs=viewquestionPstmt.executeQuery();
  ArrayList<Createquestionnr> al=new ArrayList<Createquestionnr>();
  while(rs.next())
  {
	  int q_num_id=rs.getInt(1);
	  String question=rs.getString(2);
	  int valid_answer=rs.getInt(3);
	  int type_ques_no=rs.getInt(4);
	  int hint_id=rs.getInt(5);
	  int mod_id=rs.getInt(6);
	  double uplimit=rs.getDouble(7);
	  double lowlimit=rs.getDouble(8);
	  Createquestionnr u=new Createquestionnr(q_num_id,question,valid_answer,type_ques_no,hint_id,mod_id,uplimit,lowlimit);
      u.setQ_num_id(q_num_id);
	  al.add(u);
  
  }
  return al;
}

public Collection<Createquestionnr> validate(int mod_id)throws SQLException
{
	 getquestionPstmt.setInt(1,mod_id );
	 
	 
	  ResultSet rs=getquestionPstmt.executeQuery();
	  Collection<Createquestionnr> al=new ArrayList<Createquestionnr>();
	 
	  while(rs.next())
	  {
		  int q_num_id=rs.getInt(1);
		  String question=rs.getString(2);
		  int valid_answer=rs.getInt(3);
		  int type_ques_no=rs.getInt(4);
		  int hint_id=rs.getInt(5);
		  int mod_id1=rs.getInt(6);
		  double uplimit=rs.getDouble(7);
		  double lowlimit=rs.getDouble(8);
		  Createquestionnr u=new Createquestionnr(q_num_id,question,valid_answer,type_ques_no,hint_id,mod_id1,uplimit,lowlimit);
	      u.setQ_num_id(q_num_id);
		  al.add(u);
		  
	  }
	  return al;
}
public Createquestionnr getResult(String question)throws SQLException
{
	getresultPstmt.setString(1,question );
	 
	 
	  ResultSet rs=getresultPstmt.executeQuery();
	  //Collection<Createquestions> al=new ArrayList<Createquestions>();
	 //Createquestions u=new Createquestions();
	  if(rs.next())
	  {
		  int q_num_id=rs.getInt(1);
		  String question1=rs.getString(2);
		  int valid_answer=rs.getInt(3);
		  int type_ques_no=rs.getInt(4);
		  int hint_id=rs.getInt(5);
		  int mod_id=rs.getInt(6);
		  double uplimit=rs.getDouble(7);
		  double lowlimit=rs.getDouble(8);
		  Createquestionnr u=new Createquestionnr(q_num_id,question,valid_answer,type_ques_no,hint_id,mod_id,uplimit,lowlimit);
	      u.setQ_num_id(q_num_id);
		  return u;
		  
	  }
	  else
		  return null;
  }
public Createquestionnr getAnswer(int q_num_id)throws SQLException
{
	  getanswerPstmt.setInt(1,q_num_id);
	  
	  ResultSet rs=getanswerPstmt.executeQuery();
	  if(rs.next())
	  {
		  
		  int q_num_id1=rs.getInt(1);
		  String question=rs.getString(2);
		  int valid_answer=rs.getInt(3);
		  int type_ques_no=rs.getInt(4);
		  int hint_id=rs.getInt(5);
		  int mod_id=rs.getInt(6);
		  double uplimit=rs.getDouble(7);
		  double lowlimit=rs.getDouble(8);
		  Createquestionnr c=new Createquestionnr(q_num_id1,question,valid_answer,type_ques_no,hint_id,mod_id,uplimit,lowlimit);
	      c.setQ_num_id(q_num_id);
		 
		  return c;
		  
	  }
	  else
	  {
		  return null;
	  }
}
public void update(Createquestionnr u)throws SQLException
{
	  editquestionPstmt.setInt(5, u.getQ_num_id());
	 
	  	 
	  editquestionPstmt.setString(1,u.getQuestion());
	  editquestionPstmt.setDouble(2, u.getUplimit());

	  editquestionPstmt.setDouble(3,u.getLowlimit());
	  editquestionPstmt.setInt(4, u.getValid_answer());

	  
	  editquestionPstmt.executeUpdate();
	  
	  
}

public Createquestionnr quesdetails(int q_num_id)throws SQLException
{
	 getquestiondetailsPstmt.setInt(1,q_num_id );
	 
	 
	  ResultSet rs=getquestiondetailsPstmt.executeQuery();
	  Collection<Createquestionnr> al=new ArrayList<Createquestionnr>();
	 
	  if(rs.next())
	  {
		  int q_num_id1=rs.getInt(1);
		  String question=rs.getString(2);
		  int valid_answer=rs.getInt(3);
		  int type_ques_no=rs.getInt(4);
		  int hint_id=rs.getInt(5);
		  int mod_id=rs.getInt(6);
		  double uplimit=rs.getDouble(7);
		  double lowlimit=rs.getDouble(8);
		  Createquestionnr u=new Createquestionnr(q_num_id1,question,valid_answer,type_ques_no,hint_id,mod_id,uplimit,lowlimit);
	      u.setQ_num_id(q_num_id);
		 
		  return u;  
	  }
	  else
	  {
		  return null;
	  }
}



}

