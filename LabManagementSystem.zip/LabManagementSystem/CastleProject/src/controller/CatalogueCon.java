package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.*;

/**
 * Servlet implementation class WplabCon
 */
@WebServlet("/CatalogueCon")
public class CatalogueCon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CatalogueCon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		RequestDispatcher requestd = null;
		String num=request.getParameter("num");
		String lodo=request.getParameter("lodo");
		request.setAttribute("lodo", lodo);//expno
		int l = Integer.parseInt(lodo);
		//int no = Integer.parseInt(num);
		String name=request.getParameter("name");
		System.out.println("got the Wplabcon for updating prelab status+"+name);
		HttpSession session=request.getSession();
		
		name=(String) session.getAttribute("username");
		 
		request.setAttribute("name", name);
		Dao dd=new Dao();
		String netid = dd.checknetid(name);
	    int x=dd.cq(l);
	    
	    
	    for(int i=1;i<=x;i++)
	    {
        switch (i) {
        case 1: {
        		String ans1 = request.getParameter("ans1");
        		request.setAttribute("ans1", ans1);
        		dd.pans(netid, l, 1, ans1);
                 break;
        }
        case 2: {
        	String ans2 = request.getParameter("ans2");
      
		request.setAttribute("ans2", ans2);
		dd.pans(netid, l, 2, ans2);
	
         break;
        }
        case 3: {
        	String ans3 = request.getParameter("ans3");
       
		request.setAttribute("ans3", ans3);
		dd.pans(netid, l, 3, ans3);
         break;
        }
        case 4: {
        	String ans4 = request.getParameter("ans4");
		request.setAttribute("ans4", ans4);
		dd.pans(netid, l, 4, ans4);
         break;
        }
        case 5:  {
    		String ans5 = request.getParameter("ans5");
    		request.setAttribute("ans5", ans5);
    		dd.pans(netid, l, 5, ans5);
             break;
    }
        case 6:  {
    		String ans6 = request.getParameter("ans6");
    		request.setAttribute("ans6", ans6);
    		dd.pans(netid, l, 6, ans6);
             break;
    }
        case 7:   {
    		String ans7 = request.getParameter("ans7");
    		request.setAttribute("ans7", ans7);
    		dd.pans(netid, l, 7, ans7);
             break;
    }
        case 8:  {
    		String ans8 = request.getParameter("ans8");
    		request.setAttribute("ans8", ans8);
    		dd.pans(netid, l, 8, ans8);
             break;
    }
        case 9:  {
    		String ans9 = request.getParameter("ans9");
    		request.setAttribute("ans9", ans9);
    		dd.pans(netid, l, 9, ans9);
             break;
    }
        case 10:  {
    		String ans10 = request.getParameter("ans10");
    		request.setAttribute("ans10", ans10);
    		dd.pans(netid, l, 10, ans10);
             break;
    }
        case 11: {
    		String ans11 = request.getParameter("ans11");
    		request.setAttribute("ans11", ans11);
    		dd.pans(netid, l, 11, ans11);
             break;
    }
        case 12:  {
    		String ans12 = request.getParameter("ans12");
    		request.setAttribute("ans12", ans12);
    		dd.pans(netid, l, 12, ans12);
             break;
    }
        default:
                 break;
    }
	    }
	
	
		
		dd.asslcheck(netid,l);
		int r=dd.updatepostlab(netid, l);
		

		requestd = getServletContext().getRequestDispatcher("/home.jsp");
		requestd.forward(request, response);
		
	}

}
